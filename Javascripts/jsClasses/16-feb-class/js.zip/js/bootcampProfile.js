// string - "", '', ``
let name = "Rohit";
// Number - 25, 25.9
let age = 25;

// Boolean - true, false
let isPaid = true;

let favouriteClass = null;
let hometown;

let skills = ["html", "CSS", "Javascript"];

let studentProfile = {
  name: "Haseeb",
  age: 22,
  isPaid: true,
  skills: ["HTML", "Css", "JS"],
  favouriteClass: null,
};

console.log(typeof hometown);
