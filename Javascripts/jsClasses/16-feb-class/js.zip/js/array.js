let fruits = ["apple", "cherry", "banana"];
let intFruits = new Array("kiwi", "avacado", "dragon fruit");

fruits.unshift("new item");
fruits.pop();
console.log(fruits);
