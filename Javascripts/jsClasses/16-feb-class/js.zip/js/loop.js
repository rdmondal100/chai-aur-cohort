let teas = ["masala", "ginger", "oolong", "orange", "rose", "lemon"];

//teas[h];

teas.length; // 6

//let h = 2; // h <=5 || h < 6

// loop - iteration;
//variable leke aao
// limit btao
// incre/decre =>  h = h + 1

for (let h = 0; h < teas.length + 5; h++) {
  console.log(`tea at index ${h}: ${teas[h]}`);
}
