Object.prototype.chai = function () {
  console.log("chai aur code");
};

const tea = {
  name: "Ice tea lemon",
  type: "cool",
};

tea.chai();

const myTeas = ["lemon tea", "orange tea"];
myTeas.chai();
